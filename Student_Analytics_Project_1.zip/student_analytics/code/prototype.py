"""Первый императивный прототип: переменные, состояние, if и for."""
import csv
from pathlib import Path
from math import isfinite

if __name__ == "__main__":
    text = Path(__file__).with_name("students.csv").read_text(encoding="utf-8-sig")
    source = csv.DictReader(text.splitlines(), delimiter=";")
    weights = (0.3, 0.3, 0.4)
    results = []
    seen = set()
    if source.fieldnames != ["id", "name", "practice", "midterm", "exam"]:
        raise ValueError("Неверный заголовок CSV.")
    for row in source:
        if None in row or any(value is None for value in row.values()):
            raise ValueError("Неверное количество столбцов CSV.")
        if not row["id"].strip() or not row["name"].strip():
            raise ValueError("Пустой ID или имя.")
        sid = row["id"].strip()
        if sid in seen:
            raise ValueError("Повторяющийся ID: " + sid)
        seen.add(sid)
        total = 0.0
        for index, column in enumerate(("practice", "midterm", "exam")):
            subtotal, count = 0.0, 0
            for item in row[column].split("|"):
                value = float(item)
                if not isfinite(value) or not 0 <= value <= 100:
                    raise ValueError("Неверный балл: " + item)
                subtotal += value
                count += 1
            total += weights[index] * subtotal / count
        results.append((sid, row["name"].strip(), total))
    results.sort(key=lambda row: (-row[2], row[0]))
    print("ИМПЕРАТИВНЫЙ ПРОТОТИП: WeightedPolicy, порог 50")
    for place, (sid, name, score) in enumerate(results, start=1):
        status = "Допущен" if score >= 50 else "Не допущен"
        print("{:>2}. {} {:<24} {:6.2f} {}".format(place, sid, name, score, status))
