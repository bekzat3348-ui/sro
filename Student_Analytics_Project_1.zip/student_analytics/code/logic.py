"""Импорт, чистые вычисления, сравнение парадигм и ленивый отчёт."""
import csv
from functools import reduce
from io import StringIO
from math import isclose
from models import Student, WeightedPolicy, validate_score, validate_weights


def mean_score(values):
    values = tuple(validate_score(value) for value in values)
    if not values:
        raise ValueError("Нельзя вычислить среднее пустой последовательности.")
    return sum(values) / len(values)


def parse_attempts(text):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Список попыток не должен быть пустым.")
    try:
        return tuple(validate_score(float(part)) for part in text.split("|"))
    except (ValueError, TypeError) as error:
        raise ValueError("Неверные попытки: " + repr(text)) from error


def import_records(csv_text):
    """Чистый импорт из текста: весь набор корректен либо возникает ошибка."""
    reader = csv.DictReader(StringIO(csv_text.lstrip("\ufeff")), delimiter=";")
    required = ["id", "name", "practice", "midterm", "exam"]
    if reader.fieldnames != required:
        raise ValueError("Заголовок CSV должен быть: " + ";".join(required))
    students, seen = [], set()
    for number, row in enumerate(reader, start=2):
        try:
            if None in row or any(row[key] is None for key in required):
                raise ValueError("Неверное количество столбцов.")
            grades = tuple(parse_attempts(row[key]) for key in required[2:])
            student = Student(row["id"], row["name"], grades)
            if student.student_id in seen:
                raise ValueError("Повторяющийся ID: " + student.student_id)
            students.append(student)
            seen.add(student.student_id)
        except (ValueError, TypeError) as error:
            raise ValueError("Строка {}: {}".format(number, error)) from error
    return tuple(students)


def rank_results(results):
    """Новая коллекция: балл убывает, при равенстве ID возрастает."""
    return tuple(sorted(results, key=lambda row: (-row.score, row.student_id)))


def make_threshold_predicate(threshold):
    """Замыкание запоминает порог для будущей фильтрации."""
    threshold = validate_score(threshold)
    return lambda row: row.score >= threshold


def filter_results(results, threshold):
    return tuple(filter(make_threshold_predicate(threshold), results))


def group_stats(results):
    results = tuple(results)
    scores = tuple(map(lambda row: row.score, results))
    count = len(scores)
    admitted = sum(row.admitted for row in results)
    return {"count": count, "mean": sum(scores) / count if count else None,
            "minimum": min(scores) if count else None,
            "maximum": max(scores) if count else None,
            "admitted": admitted, "not_admitted": count - admitted,
            "pass_rate": 100 * admitted / count if count else 0.0}


def flatten_grades(nested):
    """Рекурсивно обойти дерево: студенты -> категории -> попытки."""
    if isinstance(nested, (tuple, list)):
        return tuple(value for branch in nested for value in flatten_grades(branch))
    return (validate_score(nested),)


def procedural_score(student, weights=(0.3, 0.3, 0.4)):
    weights = validate_weights(weights)
    total = 0.0
    for index, group in enumerate(student.grades):
        total += mean_score(group) * weights[index]
    return total


def functional_score(student, weights=(0.3, 0.3, 0.4)):
    weights = validate_weights(weights)
    means = map(mean_score, student.grades)
    contributions = map(lambda pair: pair[0] * pair[1], zip(weights, means))
    return reduce(lambda total, value: total + value, contributions, 0.0)


def compare_paradigms(students):
    policy = WeightedPolicy()
    return tuple((s.student_id, procedural_score(s), policy.score(s),
                  functional_score(s)) for s in students)


def comparison_lines(students):
    yield "СРАВНЕНИЕ ПАРАДИГМ: одна формула WeightedPolicy"
    yield "ID    Процедурно      ООП   Функционально"
    rows = compare_paradigms(students)
    for sid, proc, oop, func in rows:
        yield "{:<5} {:>10.2f} {:>8.2f} {:>14.2f}".format(sid, proc, oop, func)
    agree = all(isclose(p, o, abs_tol=1e-9) and isclose(p, f, abs_tol=1e-9)
                for _, p, o, f in rows)
    yield "Все результаты совпадают: " + ("ДА" if agree else "НЕТ")


def report_lines(book):
    """Строки отчёта создаются по требованию с помощью yield."""
    rows = rank_results(book.results())
    stats = group_stats(rows)
    yield "Политика: {} | Порог: {:g}".format(type(book.policy).__name__, book.threshold)
    yield "Место ID   Студент                   Балл   Статус"
    yield "-" * 65
    for place, row in enumerate(rows, start=1):
        status = "Допущен" if row.admitted else "Не допущен"
        yield "{:>5} {:<4} {:<24} {:>6.2f}  {}".format(
            place, row.student_id, row.name, row.score, status)
    yield "Студентов: {} | Допущено: {} | Не допущено: {}".format(
        stats["count"], stats["admitted"], stats["not_admitted"])
    if rows:
        yield "Средний: {:.2f} | Минимум: {:.2f} | Максимум: {:.2f}".format(
            stats["mean"], stats["minimum"], stats["maximum"])
        yield "Доля допущенных: {:.1f}%".format(stats["pass_rate"])
        attempts = flatten_grades(tuple(s.grades for s in book.students))
        yield "Всего отдельных попыток: {}".format(len(attempts))
    else:
        yield "Группа пуста: средний, минимум и максимум не определены."
