"""Точка входа. Для OnlineGDB достаточно нажать Run; начнётся demo."""
from pathlib import Path
import sys
import unittest
from models import GradeBook, WeightedPolicy, BestAttemptPolicy
from logic import import_records, report_lines, comparison_lines, filter_results

MODE = "demo"  # Варианты: demo, menu, test, compare, prototype.
DATA_FILE = Path(__file__).with_name("students.csv")


def load_book(path=DATA_FILE):
    text = Path(path).read_text(encoding="utf-8-sig")
    book = GradeBook(WeightedPolicy(), threshold=50)
    for student in import_records(text):
        book.add(student)
    return book


def show_report(book):
    print("\n".join(report_lines(book)))


def show_comparison(book):
    print("\n".join(comparison_lines(book.students)))


def run_tests():
    import test_project
    suite = unittest.defaultTestLoader.loadTestsFromModule(test_project)
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(suite)
    return result.wasSuccessful()


def run_demo(book):
    print("АНАЛИТИЧЕСКАЯ СИСТЕМА УСПЕВАЕМОСТИ СТУДЕНТОВ")
    print("Учебные данные. Допуск к следующему этапу: итоговый балл >= 50.")
    print("\n1. Средние попытки с весами 30%, 30%, 40%")
    show_report(book)
    book.set_policy(BestAttemptPolicy())
    print("\n2. Лучшие попытки с теми же весами")
    show_report(book)
    book.set_policy(WeightedPolicy())
    print("\n3. Фильтр: итоговый балл >= 80 (WeightedPolicy)")
    for row in filter_results(book.results(), 80):
        print("{} {:<24} {:.2f}".format(row.student_id, row.name, row.score))
    print("\n4. Один расчёт в трёх парадигмах")
    show_comparison(book)
    print('\nДля меню: MODE = "menu". Для тестов: MODE = "test".')


def run_menu(book):
    while True:
        print("\n1 - Отчёт; 2 - Сменить политику; 3 - Изменить порог допуска")
        print("4 - Фильтр по баллу; 5 - Сравнение парадигм; 6 - Тесты")
        print("7 - Императивный прототип; 8 - Перезагрузить CSV; 0 - Выход")
        try:
            command = input("Выберите команду: ").strip()
            if command == "0":
                return
            elif command == "1":
                show_report(book)
            elif command == "2":
                choice = input("1 - WeightedPolicy; 2 - BestAttemptPolicy: ").strip()
                policies = {"1": WeightedPolicy, "2": BestAttemptPolicy}
                if choice not in policies:
                    raise ValueError("Выберите 1 или 2.")
                book.set_policy(policies[choice]())
                print("Выбрана политика: " + type(book.policy).__name__)
            elif command == "3":
                book.set_threshold(float(input("Новый порог 0..100: ")))
                print("Порог допуска: {:g}".format(book.threshold))
            elif command == "4":
                rows = filter_results(book.results(), float(input("Нижний порог: ")))
                for row in rows:
                    print("{} {}: {:.2f}".format(row.student_id, row.name, row.score))
                print("Найдено студентов: {}".format(len(rows)))
            elif command == "5":
                show_comparison(book)
            elif command == "6":
                run_tests()
            elif command == "7":
                import runpy
                runpy.run_path(str(Path(__file__).with_name("prototype.py")), run_name="__main__")
            elif command == "8":
                book = load_book()
                print("CSV загружен заново; политика WeightedPolicy, порог 50.")
            else:
                print("Неизвестная команда. Введите число 0..8.")
        except (ValueError, OSError) as error:
            print("Ошибка: {}".format(error))
        except (EOFError, KeyboardInterrupt):
            print("\nМеню завершено. Для ввода выберите Interactive Console.")
            return


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else MODE
    try:
        if mode == "test":
            return 0 if run_tests() else 1
        if mode == "prototype":
            import runpy
            runpy.run_path(str(Path(__file__).with_name("prototype.py")), run_name="__main__")
            return 0
        actions = {"demo": run_demo, "menu": run_menu, "compare": show_comparison}
        if mode not in actions:
            raise ValueError("Режимы: demo, menu, test, compare, prototype.")
        actions[mode](load_book())
        return 0
    except (ValueError, OSError) as error:
        print("Ошибка: {}".format(error))
        print("Проверьте наличие students.csv и данные в нём.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
