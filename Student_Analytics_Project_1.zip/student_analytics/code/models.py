"""Модели, проверка данных и взаимозаменяемые политики оценивания."""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from math import isfinite, isclose


def validate_score(value):
    """Вернуть конечный балл 0..100 или сообщить о неверных данных."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Балл должен быть числом, а не текстом или bool.")
    if not isfinite(value) or not 0 <= value <= 100:
        raise ValueError("Балл должен находиться в диапазоне 0..100.")
    return float(value)


def validate_weights(weights):
    values = tuple(weights)
    if len(values) != 3:
        raise ValueError("Нужно ровно три веса.")
    for value in values:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Веса должны быть числами.")
        if not isfinite(value) or value <= 0:
            raise ValueError("Веса должны быть конечными и положительными.")
    if not isclose(sum(values), 1.0, rel_tol=0, abs_tol=1e-9):
        raise ValueError("Сумма весов должна быть равна 1.")
    return values


@dataclass(frozen=True)
class Student:
    student_id: str
    name: str
    grades: tuple

    def __post_init__(self):
        if not isinstance(self.student_id, str) or not self.student_id.strip():
            raise ValueError("ID студента не должен быть пустым.")
        if not isinstance(self.name, str) or not self.name.strip():
            raise ValueError("Имя студента не должно быть пустым.")
        groups = tuple(tuple(validate_score(x) for x in g) for g in self.grades)
        if len(groups) != 3 or any(not g for g in groups):
            raise ValueError("Нужны три категории с хотя бы одной попыткой.")
        object.__setattr__(self, "student_id", self.student_id.strip())
        object.__setattr__(self, "name", self.name.strip())
        object.__setattr__(self, "grades", groups)


@dataclass(frozen=True)
class Result:
    student_id: str
    name: str
    score: float
    admitted: bool


class GradingPolicy(ABC):
    """Общий интерфейс: GradeBook вызывает score у любой политики."""
    def __init__(self, weights=(0.3, 0.3, 0.4)):
        self.__weights = validate_weights(weights)

    @property
    def weights(self):
        return self.__weights

    @abstractmethod
    def score(self, student):
        """Вернуть итоговый балл без округления."""
        raise NotImplementedError


class WeightedPolicy(GradingPolicy):
    def score(self, student):
        means = (sum(group) / len(group) for group in student.grades)
        return sum(weight * mean for weight, mean in zip(self.weights, means))


class BestAttemptPolicy(GradingPolicy):
    def score(self, student):
        best = (max(group) for group in student.grades)
        return sum(weight * value for weight, value in zip(self.weights, best))


class GradeBook:
    """Композиция студентов и политики; изменения только через методы."""
    def __init__(self, policy, threshold=50):
        self.__students = {}
        self.set_policy(policy)
        self.set_threshold(threshold)

    @property
    def students(self):
        return tuple(self.__students.values())

    @property
    def policy(self):
        return self.__policy

    @property
    def threshold(self):
        return self.__threshold

    def add(self, student):
        if not isinstance(student, Student):
            raise ValueError("В журнал можно добавить только Student.")
        if student.student_id in self.__students:
            raise ValueError("Повторяющийся ID: " + student.student_id)
        self.__students[student.student_id] = student

    def set_policy(self, policy):
        if not isinstance(policy, GradingPolicy):
            raise ValueError("Политика должна реализовывать GradingPolicy.")
        self.__policy = policy

    def set_threshold(self, threshold):
        self.__threshold = validate_score(threshold)

    def results(self):
        rows = []
        for student in self.students:
            value = self.policy.score(student)
            rows.append(Result(student.student_id, student.name,
                               value, value >= self.threshold))
        return tuple(rows)
