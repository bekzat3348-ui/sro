"""Автоматические тесты мини-проекта. Запуск: python -m unittest test_project -v."""

import inspect
import unittest
from dataclasses import FrozenInstanceError

from models import (
    BestAttemptPolicy,
    GradeBook,
    Result,
    Student,
    WeightedPolicy,
    validate_score,
)
from logic import (
    filter_results,
    flatten_grades,
    functional_score,
    group_stats,
    import_records,
    make_threshold_predicate,
    mean_score,
    procedural_score,
    rank_results,
    report_lines,
)


class ProjectTests(unittest.TestCase):
    """Нормальные, граничные и ошибочные сценарии: 28 тестов."""

    def setUp(self):
        self.student = Student("S01", "Анна", ((60, 80), (80,), (50, 100)))
        self.header = "id;name;practice;midterm;exam\n"
        self.rows = (
            Result("S02", "Борис", 80.0, True),
            Result("S01", "Анна", 80.0, True),
            Result("S03", "Дана", 20.0, False),
        )

    def test_01_valid_score_boundaries(self):
        """Допустимы 0, 100 и дробный балл внутри диапазона."""
        for value in (0, 100, 72.5):
            with self.subTest(value=value):
                self.assertEqual(validate_score(value), float(value))

    def test_02_invalid_scores_are_rejected(self):
        """Недопустимые числа, логические значения и текст отклоняются."""
        values = (-0.01, 100.01, float("nan"), float("inf"),
                  -float("inf"), True, False, "не число", None)
        for value in values:
            with self.subTest(value=repr(value)):
                with self.assertRaises((ValueError, TypeError)):
                    validate_score(value)

    def test_03_student_state_is_immutable(self):
        """Изменение исходного списка не меняет сохранённые оценки."""
        source = [[60, 80], [80], [50, 100]]
        student = Student("S01", "Анна", source)
        source[0][0] = 0
        self.assertEqual(student.grades[0][0], 60)
        self.assertIsInstance(student.grades, tuple)
        self.assertTrue(all(isinstance(part, tuple) for part in student.grades))
        with self.assertRaises((FrozenInstanceError, AttributeError, TypeError)):
            student.name = "Другое имя"

    def test_04_student_identifiers_and_names_are_required(self):
        """Пустые идентификатор и имя не образуют корректную запись."""
        for student_id, name in (("", "Анна"), ("  ", "Анна"),
                                 ("S01", ""), ("S01", "   ")):
            with self.subTest(student_id=student_id, name=name):
                with self.assertRaises((ValueError, TypeError)):
                    Student(student_id, name, ((50,), (50,), (50,)))

    def test_05_student_requires_three_nonempty_categories(self):
        """Все три категории оценивания обязательны."""
        cases = ((), ((50,), (60,)), ((50,), (), (60,)),
                 ((50,), (60,), (70,), (80,)))
        for grades in cases:
            with self.subTest(grades=grades):
                with self.assertRaises((ValueError, TypeError)):
                    Student("S01", "Анна", grades)

    def test_06_weighted_policy_known_example(self):
        """Средние 70, 80, 75 с весами 0.3/0.3/0.4 дают 75."""
        self.assertAlmostEqual(WeightedPolicy().score(self.student), 75.0)

    def test_07_best_attempt_policy_known_example(self):
        """Лучшие попытки 80, 80, 100 дают итоговый балл 88."""
        self.assertAlmostEqual(BestAttemptPolicy().score(self.student), 88.0)

    def test_08_invalid_weight_vectors_are_rejected(self):
        """Неполные, нулевые и отрицательные веса недопустимы."""
        for policy_type in (WeightedPolicy, BestAttemptPolicy):
            for weights in ((0.5, 0.5), (0, 0, 0), (-0.1, 0.5, 0.6)):
                with self.subTest(policy=policy_type.__name__, weights=weights):
                    with self.assertRaises((ValueError, TypeError)):
                        policy_type(weights)

    def test_09_duplicate_student_is_rejected(self):
        """Повтор идентификатора не добавляет вторую запись в ведомость."""
        book = GradeBook(WeightedPolicy())
        book.add(self.student)
        duplicate = Student("S01", "Другое имя", ((90,), (90,), (90,)))
        with self.assertRaises((ValueError, TypeError)):
            book.add(duplicate)
        self.assertEqual(len(book.students), 1)

    def test_10_students_property_protects_the_collection(self):
        """Внешний код получает неизменяемую коллекцию студентов."""
        book = GradeBook(WeightedPolicy())
        book.add(self.student)
        snapshot = book.students
        self.assertIsInstance(snapshot, tuple)
        extended = snapshot + (Student("S02", "Борис", ((60,), (60,), (60,))),)
        self.assertEqual(len(extended), 2)
        self.assertEqual(len(book.students), 1)

    def test_11_policy_can_be_replaced(self):
        """Замена стратегии меняет расчёт без пересоздания ведомости."""
        book = GradeBook(WeightedPolicy())
        book.add(self.student)
        self.assertAlmostEqual(book.results()[0].score, 75.0)
        book.set_policy(BestAttemptPolicy())
        self.assertAlmostEqual(book.results()[0].score, 88.0)
        self.assertEqual(book.students, (self.student,))

    def test_12_admission_threshold_is_inclusive(self):
        """Ровно 50 баллов достаточно при пороге 50."""
        book = GradeBook(WeightedPolicy(), threshold=50)
        book.add(Student("S01", "Анна", ((50,), (50,), (50,))))
        self.assertTrue(book.results()[0].admitted)

    def test_13_admission_does_not_use_display_rounding(self):
        """49.999 не превращается в допуск из-за округления до 50.00."""
        book = GradeBook(WeightedPolicy(), threshold=50)
        book.add(Student("S01", "Анна", ((49.999,), (49.999,), (49.999,))))
        result = book.results()[0]
        self.assertLess(result.score, 50)
        self.assertFalse(result.admitted)

    def test_14_threshold_updates_and_rejects_invalid_value(self):
        """Новый порог пересчитывает допуск; ошибка не портит состояние."""
        book = GradeBook(WeightedPolicy(), threshold=50)
        book.add(self.student)
        book.set_threshold(80)
        self.assertFalse(book.results()[0].admitted)
        with self.assertRaises((ValueError, TypeError)):
            book.set_threshold(101)
        self.assertEqual(book.threshold, 80)
        book.set_threshold(75)
        self.assertTrue(book.results()[0].admitted)

    def test_15_valid_csv_import_preserves_attempts(self):
        """CSV загружается с несколькими попытками в одной категории."""
        text = self.header + 'S01;"Анна; А.";60|80;80;50|100\n'
        students = import_records(text)
        self.assertEqual(len(students), 1)
        self.assertEqual(students[0].student_id, "S01")
        self.assertEqual(students[0].name, "Анна; А.")
        self.assertEqual(students[0].grades, ((60.0, 80.0), (80.0,), (50.0, 100.0)))

    def test_16_csv_rejects_missing_fields_and_duplicates(self):
        """Пустое имя, пустой ID и повтор ID отклоняются при импорте."""
        cases = (
            "S01;;60;70;80\n",
            ";Анна;60;70;80\n",
            "S01;Анна;60;70;80\nS01;Борис;90;90;90\n",
        )
        for body in cases:
            with self.subTest(body=body):
                with self.assertRaises((ValueError, TypeError)):
                    import_records(self.header + body)

    def test_17_csv_rejects_bad_structure(self):
        """Отсутствующий заголовок и лишние/недостающие поля отклоняются."""
        cases = (
            "id;name;practice;midterm\nS01;Анна;60;70\n",
            self.header + "S01;Анна;60;70\n",
            self.header + "S01;Анна;60;70;80;лишнее\n",
            "S01;Анна;60;70;80\n",
        )
        for text in cases:
            with self.subTest(text=text):
                with self.assertRaises((ValueError, TypeError)):
                    import_records(text)

    def test_18_csv_rejects_invalid_or_empty_attempts(self):
        """Некорректная попытка не теряется незаметно при разборе CSV."""
        for value in ("", "60||80", "abc", "-1", "101", "nan", "inf"):
            with self.subTest(value=value):
                with self.assertRaises((ValueError, TypeError)):
                    import_records(self.header + "S01;Анна;" + value + ";70;80\n")

    def test_19_mean_score_and_empty_sequence(self):
        """Среднее вычисляется правильно; пустой список не имеет среднего."""
        self.assertAlmostEqual(mean_score((40, 60, 80)), 60)
        self.assertAlmostEqual(mean_score((72.5,)), 72.5)
        with self.assertRaises((ValueError, TypeError)):
            mean_score(())

    def test_20_ranking_is_deterministic_on_equal_scores(self):
        """При равных баллах меньший ID идёт первым; исходник не меняется."""
        source = list(self.rows)
        original = source.copy()
        ranked = rank_results(source)
        self.assertEqual(tuple(row.student_id for row in ranked), ("S01", "S02", "S03"))
        self.assertEqual(source, original)

    def test_21_threshold_closure_and_filter(self):
        """Замыкание помнит порог и включает записи на самой границе."""
        predicate = make_threshold_predicate(80)
        self.assertTrue(predicate(self.rows[0]))
        self.assertFalse(predicate(self.rows[2]))
        selected = filter_results(self.rows, 80)
        self.assertEqual({row.student_id for row in selected}, {"S01", "S02"})
        self.assertEqual(filter_results(self.rows, 81), ())

    def test_22_group_statistics_known_example(self):
        """Статистика рассчитывается из оценок и статусов всех записей."""
        stats = group_stats(self.rows)
        self.assertEqual(stats["count"], 3)
        self.assertAlmostEqual(stats["mean"], 60)
        self.assertEqual(stats["minimum"], 20)
        self.assertEqual(stats["maximum"], 80)
        self.assertEqual(stats["admitted"], 2)
        self.assertEqual(stats["not_admitted"], 1)
        self.assertAlmostEqual(stats["pass_rate"], 100 * 2 / 3)

    def test_23_empty_group_has_defined_statistics(self):
        """У пустой группы нет среднего, минимума и максимума."""
        stats = group_stats(())
        self.assertEqual(stats["count"], 0)
        self.assertIsNone(stats["mean"])
        self.assertIsNone(stats["minimum"])
        self.assertIsNone(stats["maximum"])
        self.assertEqual(stats["admitted"], 0)
        self.assertEqual(stats["not_admitted"], 0)
        self.assertEqual(stats["pass_rate"], 0)

    def test_24_recursive_flatten_preserves_order_and_validates(self):
        """Рекурсия обходит уровни вложенности и проверяет листья."""
        self.assertEqual(flatten_grades(([10, [20]], (30, (40, 50)))),
                         (10.0, 20.0, 30.0, 40.0, 50.0))
        self.assertEqual(flatten_grades(()), ())
        with self.assertRaises((ValueError, TypeError)):
            flatten_grades(((50,), (101,)))

    def test_25_pure_functions_preserve_inputs(self):
        """Аналитика не изменяет переданные коллекции."""
        scores = [40, 60, 80]
        rows = list(self.rows)
        nested = [[40, 60], [80]]
        original_scores = scores.copy()
        original_rows = rows.copy()
        original_nested = [part.copy() for part in nested]
        mean_score(scores)
        rank_results(rows)
        filter_results(rows, 50)
        group_stats(rows)
        flatten_grades(nested)
        self.assertEqual(scores, original_scores)
        self.assertEqual(rows, original_rows)
        self.assertEqual(nested, original_nested)

    def test_26_report_is_a_generator_with_student_data(self):
        """Строки отчёта выдаются генератором и содержат запись студента."""
        book = GradeBook(WeightedPolicy())
        book.add(self.student)
        lines = report_lines(book)
        self.assertTrue(inspect.isgenerator(lines))
        output = "\n".join(lines)
        self.assertIn("S01", output)
        self.assertIn("Анна", output)
        self.assertIn("75", output)

    def test_27_three_paradigms_produce_the_same_result(self):
        """Три реализации одного правила дают одинаковый результат."""
        examples = (
            self.student,
            Student("S02", "Борис", ((0,), (0,), (0,))),
            Student("S03", "Дана", ((100,), (100,), (100,))),
            Student("S04", "Ерлан", ((20, 50, 95), (43, 88), (72.5,))),
        )
        for student in examples:
            with self.subTest(student=student.student_id):
                expected = WeightedPolicy().score(student)
                self.assertAlmostEqual(procedural_score(student), expected)
                self.assertAlmostEqual(functional_score(student), expected)

    def test_28_custom_weights_are_used_consistently(self):
        """Настраиваемые веса одинаково применяются во всех решениях."""
        weights = (0.2, 0.3, 0.5)
        expected = 70 * 0.2 + 80 * 0.3 + 75 * 0.5
        self.assertAlmostEqual(WeightedPolicy(weights).score(self.student), expected)
        self.assertAlmostEqual(procedural_score(self.student, weights), expected)
        self.assertAlmostEqual(functional_score(self.student, weights), expected)
        self.assertAlmostEqual(BestAttemptPolicy(weights).score(self.student), 90)


if __name__ == "__main__":
    unittest.main(verbosity=2)
